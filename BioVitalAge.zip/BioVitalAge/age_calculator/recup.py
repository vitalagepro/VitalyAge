
from django.http import JsonResponse
from django.shortcuts import render
from .models import AgeData
def view_data(request):
    # Recupera tutti i dati ordinati per data di visita
    age_data = AgeData.objects.all().order_by('-visit_date')
    return render(request, 'age_calculator/data_view.html', {'age_data': age_data})
