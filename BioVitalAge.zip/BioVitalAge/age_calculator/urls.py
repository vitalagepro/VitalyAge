# age_calculator/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('calculate/', views.calculate_view, name='calculate'),
    path('get_age_trends/', views.get_age_trends, name='get_age_trends'),
    path('data_view/', views.view_data, name='data_view'),
    path('search_patient/<str:codice_fiscale>/', views.search_patient, name='search_patient'),
    path('patient/<int:patient_id>/', views.patient_detail, name='patient_detail'),
]
