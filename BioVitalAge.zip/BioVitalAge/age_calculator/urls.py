# age_calculator/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('calculate/', views.calculate_view, name='calculate'),
    path('get_age_trends/', views.get_age_trends, name='get_age_trends'),
    path('data_view/', views.view_data, name='data_view'),
]
