from django.db import models

class AgeData(models.Model):
    chronological_age = models.IntegerField()
    biological_age = models.IntegerField()
    visit_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.visit_date}: {self.biological_age}"

class PatientData(models.Model):
    name = models.CharField(max_length=100)
    surname = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=1, choices=[('M', 'Male'), ('F', 'Female')])
    place_of_birth = models.CharField(max_length=100)
    codice_fiscale = models.CharField(max_length=16)

    # Valori dei biomarcatori
    chronological_age = models.IntegerField()
    obri_index = models.FloatField()
    d_roms = models.FloatField()
    aa_epa = models.FloatField()
    aa_dha = models.FloatField()
    homa_test = models.FloatField()
    cardiovascular_risk = models.FloatField()
    osi = models.FloatField()
    pat = models.FloatField()

    # Esami del sangue
    wbc = models.FloatField()
    baso = models.FloatField()
    eosi = models.FloatField()
    lymph = models.FloatField()
    mono = models.FloatField()
    neut = models.FloatField()

    # Globuli rossi
    rbc = models.FloatField()
    hct = models.FloatField()
    hgb = models.FloatField()
    mch = models.FloatField()
    mchc = models.FloatField()
    mcv = models.FloatField()

    # Altri marcatori chiave
    glucose = models.FloatField()
    creatinine = models.FloatField()
    ferritin = models.FloatField()
    albumin = models.FloatField()
    protein = models.FloatField()
    bilirubin = models.FloatField()
    uric_acid = models.FloatField()

    visit_date = models.DateTimeField(auto_now_add=True)  # Data di visita automatica

    def __str__(self):
        return f"{self.name} {self.surname} - {self.visit_date}"
