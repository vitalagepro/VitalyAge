import json
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.csrf import csrf_exempt
from .models import  PatientData
from .utils import calculate_biological_age  # Assicurati che calculate_biological_age sia importata correttamente

@csrf_exempt  # Usa solo temporaneamente, se necessario
def calculate_view(request):
    if request.method == 'POST':
        try:
            # Ricevi i dati JSON dal form
          
            data = json.loads(request.body)
            
            # Informazioni del paziente
            name = data.get('name', '')
            surname = data.get('surname', '')
            dob = data.get('dob')
            gender = data.get('gender', '')
            place_of_birth = data.get('place_of_birth', '')
            codice_fiscale = data.get('codice_fiscale', '')

            # Dati dei biomarcatori
            chronological_age = int(data.get('chronological_age', 0))
            obri_index = float(data.get('obri_index', 0))
            d_roms = float(data.get('d_roms', 0))
            aa_epa = float(data.get('aa_epa', 0))
            aa_dha = float(data.get('aa_dha', 0))
            homa_test = float(data.get('homa_test', 0))
            cardiovascular_risk = float(data.get('cardiovascular_risk', 0))
            osi = float(data.get('osi', 0))
            pat = float(data.get('pat', 0))

            # Esami del sangue
            wbc = float(data.get('wbc', 0))
            baso = float(data.get('baso', 0))
            eosi = float(data.get('eosi', 0))
            lymph = float(data.get('lymph', 0))
            mono = float(data.get('mono', 0))
            neut = float(data.get('neut', 0))

            # Globuli rossi
            rbc = float(data.get('rbc', 0))
            hct = float(data.get('hct', 0))
            hgb = float(data.get('hgb', 0))
            mch = float(data.get('mch', 0))
            mchc = float(data.get('mchc', 0))
            mcv = float(data.get('mcv', 0))

            # Altri marcatori chiave
            glucose = float(data.get('glucose', 0))
            creatinine = float(data.get('creatinine', 0))
            ferritin = float(data.get('ferritin', 0))
            albumin = float(data.get('albumin', 0))
            protein = float(data.get('protein', 0))
            bilirubin = float(data.get('bilirubin', 0))
            uric_acid = float(data.get('uric_acid', 0))
            exams = data.get('exams', {})

            # Calcola l'età biologica
            biological_age = calculate_biological_age(
                chronological_age, obri_index, d_roms, aa_epa, aa_dha, homa_test, cardiovascular_risk, osi, pat, exams
            )

            # Salva i dati nel database
            PatientData.objects.create(chronological_age=chronological_age, biological_age=biological_age,name=name,
                surname=surname,
                dob=dob,
                gender=gender,
                place_of_birth=place_of_birth,
                codice_fiscale=codice_fiscale,
                
                obri_index=obri_index,
                d_roms=d_roms,
                aa_epa=aa_epa,
                aa_dha=aa_dha,
                homa_test=homa_test,
                cardiovascular_risk=cardiovascular_risk,
                osi=osi,
                pat=pat,
                wbc=wbc,
                baso=baso,
                eosi=eosi,
                lymph=lymph,
                mono=mono,
                neut=neut,
                rbc=rbc,
                hct=hct,
                hgb=hgb,
                mch=mch,
                mchc=mchc,
                mcv=mcv,
                glucose=glucose,
                creatinine=creatinine,
                ferritin=ferritin,
                albumin=albumin,
                protein=protein,
                bilirubin=bilirubin,
                uric_acid=uric_acid)

            # Restituisce l'età biologica calcolata come JSON
            return JsonResponse({"biological_age": biological_age})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Metodo non supportato"}, status=405)


def get_age_trends(request):
    age_data = PatientData.objects.all().order_by('visit_date').values('chronological_age', 'biological_age', 'visit_date')
    return JsonResponse(list(age_data), safe=False)

def index(request):
    return render(request, 'age_calculator/index.html') 

def view_data(request):
    # Recupera tutti i dati ordinati per data di visita
    age_data = PatientData.objects.all().order_by('-visit_date')
    return render(request, 'age_calculator/data_view.html', {'age_data': age_data})
def search_patient(request, codice_fiscale):
    try:
        # Cerca il paziente tramite codice fiscale
        patient = get_object_or_404(PatientData, codice_fiscale=codice_fiscale)
        
        # Restituisce i dati del paziente in formato JSON
        data = {
            "name": patient.name,
            "surname": patient.surname,
            "dob": patient.dob,
            "codice_fiscale": patient.codice_fiscale,
            "biological_age": patient.biological_age,
        }
        return JsonResponse(data)
    except PatientData.DoesNotExist:
        return JsonResponse({"error": "Paziente non trovato."})
    # Recupera il paziente usando il suo ID o restituisce 404 se non trovato
    patient = get_object_or_404(PatientData, id=patient_id)

    # Passa i dati al template
    return render(request, 'age_calculator/patient_detail.html', {'patient': patient})
def patient_detail(request, patient_id):
    # Recupera il paziente usando il suo ID o restituisce 404 se non trovato
    patient = get_object_or_404(PatientData, id=patient_id)

    # Passa i dati al template
    return render(request, 'age_calculator/patient_detail.html', {'patient': patient})