import json
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import AgeData
from .utils import calculate_biological_age  # Assicurati che calculate_biological_age sia importata correttamente

@csrf_exempt  # Usa solo temporaneamente, se necessario
def calculate_view(request):
    if request.method == 'POST':
        try:
            # Ricevi i dati JSON dal form
            data = json.loads(request.body)
            chronological_age = int(data.get('chronological_age', 0))
            obri_index = float(data.get('obri_index', 0))
            d_roms = float(data.get('d_roms', 0))
            aa_epa = float(data.get('aa_epa', 0))
            aa_dha = float(data.get('aa_dha', 0))
            homa_test = float(data.get('homa_test', 0))
            cardiovascular_risk = float(data.get('cardiovascular_risk', 0))
            osi = float(data.get('osi', 0))
            pat = float(data.get('pat', 0))
            exams = data.get('exams', {})

            # Calcola l'età biologica
            biological_age = calculate_biological_age(
                chronological_age, obri_index, d_roms, aa_epa, aa_dha, homa_test, cardiovascular_risk, osi, pat, exams
            )

            # Salva i dati nel database
            AgeData.objects.create(chronological_age=chronological_age, biological_age=biological_age)

            # Restituisce l'età biologica calcolata come JSON
            return JsonResponse({"biological_age": biological_age})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Metodo non supportato"}, status=405)


def get_age_trends(request):
    age_data = AgeData.objects.all().order_by('visit_date').values('chronological_age', 'biological_age', 'visit_date')
    return JsonResponse(list(age_data), safe=False)

def index(request):
    return render(request, 'age_calculator/index.html') 

def view_data(request):
    # Recupera tutti i dati ordinati per data di visita
    age_data = AgeData.objects.all().order_by('-visit_date')
    return render(request, 'age_calculator/data_view.html', {'age_data': age_data})
