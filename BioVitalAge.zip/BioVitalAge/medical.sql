DROP TABLE IF EXISTS VisitData;
DROP TABLE IF EXISTS PatientData;
CREATE TABLE IF NOT EXISTS PatientData (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    surname VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    gender CHAR(1) NOT NULL CHECK (gender IN ('M', 'F')),
    place_of_birth VARCHAR(100) NOT NULL,
    codice_fiscale CHAR(16) NOT NULL,

    chronological_age INT NOT NULL,
    biological_age FLOAT NOT NULL,
    obri_index FLOAT NOT NULL,
    d_roms FLOAT NOT NULL,
    aa_epa FLOAT NOT NULL,
    aa_dha FLOAT NOT NULL,
    homa_test FLOAT NOT NULL,
    cardiovascular_risk FLOAT NOT NULL,
    osi FLOAT NOT NULL,
    pat FLOAT NOT NULL,

    wbc FLOAT NOT NULL,
    baso FLOAT NOT NULL,
    eosi FLOAT NOT NULL,
    lymph FLOAT NOT NULL,
    mono FLOAT NOT NULL,
    neut FLOAT NOT NULL,

    rbc FLOAT NOT NULL,
    hct FLOAT NOT NULL,
    hgb FLOAT NOT NULL,
    mch FLOAT NOT NULL,
    mchc FLOAT NOT NULL,
    mcv FLOAT NOT NULL,

    glucose FLOAT NOT NULL,
    creatinine FLOAT NOT NULL,
    ferritin FLOAT NOT NULL,
    albumin FLOAT NOT NULL,
    protein FLOAT NOT NULL,
    bilirubin FLOAT NOT NULL,
    uric_acid FLOAT NOT NULL,

    visit_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS VisitData (
    id INT NOT NULL AUTO_INCREMENT,
    patient_id INT NOT NULL,  -- Relazione con PatientData tramite ID del paziente
    visit_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    
    PRIMARY KEY (id),
    FOREIGN KEY (patient_id) REFERENCES PatientData(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
